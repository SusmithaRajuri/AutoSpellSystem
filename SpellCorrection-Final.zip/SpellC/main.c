#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define ALPHA_SIZE 26

typedef struct n node;
struct n
{
    bool isEOW;
    node *next[ALPHA_SIZE];
};

node *root;
node* createNode()
{
    node *newNode = malloc(sizeof(node));
    newNode->isEOW = false;
    int i;
    for(i=0; i<ALPHA_SIZE; i++)
        newNode->next[i] = NULL;

    return newNode;
}

void insertWord(node *root, char w[])
{
    int i;
    int len = strlen(w);
    node *temp = root;
    for(i=0; i<len; i++)
    {
        int idx = w[i]-'a';

        if(temp->next[idx]==NULL)
            temp->next[idx] = createNode();
        temp = temp->next[idx];
    }
    temp->isEOW = true;
}

bool hasWord(node *root, char w[])
{
    int i;
    int len = strlen(w);
    node *temp = root;
    for(i=0; i<len; i++)
    {
        int idx = w[i]-'a';

        if(temp->next[idx]==NULL)
            return false;
        temp = temp->next[idx];
    }
    return temp->isEOW;
}


void replace(char w[])
{
    int i;
    int len = strlen(w);
    for(i=0; i<=len-1; i++)
    {
        char c = w[i];

        char ch;
        for(ch='a'; ch<='z'; ch++)
        {
            if(w[i]!=ch)
            {
                w[i] = ch;

                if(hasWord(root, w))
                    printf("\nREP: %s", w);

            }
        }
        w[i]=c;

    }
}

void insert(char w[])
{
    int len =strlen(w);

    char *nw = malloc(len+2);

    sprintf(nw, "%c%s",'~', w);

    /*
    nw[0]='~';
    strcpy(nw+1, w);
    */

    int i;
    for(i=0; i<=len; i++)
    {
        char ch;
        for(ch='a'; ch<='z'; ch++)
        {
            nw[i]=ch;
            if(hasWord(root, nw))
                printf("\nINS: %s", nw);
        }
        nw[i]=nw[i+1];
    }
}
void deletion(char w[])
{
    int len = strlen(w);
    char *nw = malloc(len);

    int i;
    for(i=0; i<=len-1; i++)
    {
        int j;
        for(j=0; j<=len-1; j++)
        {
            if(j<i)
                nw[j]=w[j];
            else
                nw[j]=w[j+1];
        }
        if(hasWord(root, nw))
            printf("\nDEL: %s", nw);
    }
}

void swap(char w[], int i, int j)
{
    char ch = w[i];
    w[i] = w[j];
    w[j] = ch;
}
void swapAlternate(char w[])
{
    int i;
    int len = strlen(w);
    for(i=0; i<=len-2; i++)
    {
        swap(w, i, i+1);
        if(hasWord(root, w))
            printf("\nSWP: %s", w);
        swap(w, i, i+1);
    }
}

int main()
{
    root= createNode();

    FILE *fp = fopen("dictionary.txt", "r");

    if(fp==NULL)
    {
        printf("File Not Found");
        return 1;
    }

    char w[200];
    while(!feof(fp))
    {
        fscanf(fp, "%s", w);
        insertWord(root, w);
    }

    fclose(fp);

    char mw[200];
    printf("\nEnter mis-spelt word: ");
    scanf("%s", mw);

    replace(mw);
    insert(mw);
    deletion(mw);
    swapAlternate(mw);

    return 0;
}
